# Zombie-Slayer

To learn the FPS concepts I decided to make a minimal shooter game.

The game conists of a room and a player. From the edges of the room zombies spawn and run towards the player. Player shoots to kill the zombies and dies if gets caught.

## Screenshots

The zombies also make a groaning sound when near the player. And there's a background sound as well.

### Main Screen

![image](https://github.com/zekicaneksi/Zombie-Slayer/assets/59491631/0581bf92-813e-4a76-bde7-8174ebdb686b)

### In game

![image](https://github.com/zekicaneksi/Zombie-Slayer/assets/59491631/23a88e26-80c7-41b5-a995-3a6c23fc382b)

### Shooting

![image](https://github.com/zekicaneksi/Zombie-Slayer/assets/59491631/42c5b4a7-dbba-4265-994c-d578d88e2ef7)

### Pause Screen

![image](https://github.com/zekicaneksi/Zombie-Slayer/assets/59491631/67a3431a-3e99-4c08-a737-c89717563718)

### Death Screen

![image](https://github.com/zekicaneksi/Zombie-Slayer/assets/59491631/054125fd-5edb-43cf-9214-d0caf3b60107)

